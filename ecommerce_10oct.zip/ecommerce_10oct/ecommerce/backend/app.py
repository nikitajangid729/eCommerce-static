from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient

app = Flask(__name__)
CORS(app)

# Replace the connection URL with your MongoDB Atlas connection URL
client = MongoClient('mongodb+srv://niki:niki@cluster0.2ewzeoe.mongodb.net/registrations?retryWrites=true&w=majority')

# Access your MongoDB Atlas database and collection
db = client.registrations  # Use the "registrations" database
collection = db.users  # Use the "users" collection

@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    # Assuming the data contains 'fullName', 'email', 'username', 'mobileNumber', 'password'
    # You may need to adjust the keys based on the actual keys in your form
    user_data = {
        'fullName': data['fullName'],
        'email': data['email'],
        'username': data['username'],
        'mobileNumber': data['mobileNumber'],
        'password': data['password']
    }
    # Insert the user data into the MongoDB collection
    result = collection.insert_one(user_data)
    
    if result.inserted_id:
        response = {
            'message': 'User registered successfully',
            'user_id': str(result.inserted_id)
        }
        return jsonify(response), 201
    else:
        return jsonify({'message': 'Failed to register user'}), 500

if __name__ == '__main__':
    app.run(debug=True)  # Run the Flask app in debug mode
